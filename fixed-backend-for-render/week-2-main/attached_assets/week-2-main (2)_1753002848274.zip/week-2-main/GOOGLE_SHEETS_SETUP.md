# Google Sheets Integration Setup Guide

This project includes mock Google Sheets integration that you can easily replace with actual Google Sheets API calls. Follow this guide to connect your feedback system to your own Google Sheets document.

## Quick Setup Steps

### 1. Create Your Google Sheets Document
1. Go to [Google Sheets](https://sheets.google.com)
2. Create a new spreadsheet
3. Set up your columns in Row 1:
   - **A1**: Timestamp
   - **B1**: Rating
   - **C1**: Type
   - **D1**: Comments
   - **E1**: Email
4. Copy the Spreadsheet ID from the URL (it's the long string between `/d/` and `/edit`)

### 2. Enable Google Sheets API
1. Visit [Google Cloud Console](https://console.cloud.google.com)
2. Create a new project or select an existing one
3. Search for "Google Sheets API" and enable it
4. Go to "Credentials" → "Create Credentials" → "Service Account"
5. Fill in the service account details
6. Click "Create and Continue"
7. Skip granting access (click "Continue")
8. Skip granting user access (click "Done")

### 3. Create Service Account Key
1. Click on the service account you just created
2. Go to "Keys" tab → "Add Key" → "Create New Key"
3. Choose JSON format and click "Create"
4. Download the JSON file (keep it secure!)

### 4. Share Your Spreadsheet
1. Open your Google Sheets document
2. Click "Share" button
3. Add the service account email (found in the JSON file as `client_email`)
4. Give it "Editor" permissions

### 5. Add Environment Variables
Create a `.env` file in your project root with these values:

```env
GOOGLE_SHEETS_SPREADSHEET_ID=your_spreadsheet_id_here
GOOGLE_SHEETS_RANGE=Sheet1!A:E
GOOGLE_SERVICE_ACCOUNT_EMAIL=your-service-account@project.iam.gserviceaccount.com
GOOGLE_PRIVATE_KEY="-----BEGIN PRIVATE KEY-----\nYOUR_PRIVATE_KEY_HERE\n-----END PRIVATE KEY-----"
```

**Note**: Replace the `\n` in the private key with actual line breaks, or keep as `\n` and handle parsing in code.

### 6. Install Required Dependencies
```bash
npm install googleapis google-spreadsheet
```

### 7. Replace Mock Implementation
The current mock implementation is in `client/src/lib/google-sheets.ts`. Replace the mock functions with actual API calls:

```typescript
import { GoogleSpreadsheet } from 'google-spreadsheet';

export class GoogleSheetsService {
  private doc: GoogleSpreadsheet;

  constructor(config: GoogleSheetsConfig) {
    this.doc = new GoogleSpreadsheet(config.spreadsheetId);
  }

  async appendFeedback(feedbackData: {
    timestamp: string;
    rating: number;
    type: string;
    comments: string;
    email?: string;
  }): Promise<{ success: boolean; message: string }> {
    try {
      await this.doc.useServiceAccountAuth({
        client_email: process.env.GOOGLE_SERVICE_ACCOUNT_EMAIL!,
        private_key: process.env.GOOGLE_PRIVATE_KEY!.replace(/\\n/g, '\n'),
      });

      await this.doc.loadInfo();
      const sheet = this.doc.sheetsByIndex[0];

      await sheet.addRow({
        Timestamp: feedbackData.timestamp,
        Rating: feedbackData.rating,
        Type: feedbackData.type,
        Comments: feedbackData.comments,
        Email: feedbackData.email || '',
      });

      return { success: true, message: 'Feedback saved to Google Sheets' };
    } catch (error) {
      console.error('Google Sheets error:', error);
      return { success: false, message: 'Failed to save to Google Sheets' };
    }
  }
}
```

### 8. Update Server Route
In `server/routes.ts`, update the feedback endpoint to actually call Google Sheets:

```typescript
import { googleSheetsService } from "../client/src/lib/google-sheets";

// In the POST /api/feedback route:
const feedback = await storage.insertFeedback(validatedData);

// Add this line to save to Google Sheets:
await googleSheetsService.appendFeedback({
  timestamp: feedback.timestamp.toISOString(),
  rating: feedback.rating,
  type: feedback.type,
  comments: feedback.comments,
  email: feedback.email || undefined,
});
```

## Demo Spreadsheet Template

You can copy this template: [Feedback System Template](https://docs.google.com/spreadsheets/d/1234567890abcdefghijklmnopqrstuvwxyz/edit#gid=0)

## Troubleshooting

- **Authentication Error**: Check that your service account email has access to the spreadsheet
- **Permission Error**: Ensure the service account has "Editor" permissions on the sheet
- **Invalid Key**: Make sure the private key format is correct with proper line breaks
- **Spreadsheet Not Found**: Verify the spreadsheet ID in your environment variables

## Current Status

The system currently uses **mock implementation** for Google Sheets. All feedback is stored in memory and will be lost when the server restarts. Follow the steps above to connect to real Google Sheets storage.