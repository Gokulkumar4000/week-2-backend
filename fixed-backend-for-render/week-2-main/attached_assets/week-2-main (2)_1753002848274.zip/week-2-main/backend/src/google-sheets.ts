import { GoogleSpreadsheet } from "google-spreadsheet";

export interface GoogleSheetsConfig {
  spreadsheetId: string;
  range: string;
  serviceAccountEmail: string;
  privateKey: string;
}

export class GoogleSheetsService {
  private config: GoogleSheetsConfig;

  constructor(config: GoogleSheetsConfig) {
    this.config = config;
  }

  private async getSheet() {
    const doc = new GoogleSpreadsheet(this.config.spreadsheetId);

    await doc.useServiceAccountAuth({
      client_email: this.config.serviceAccountEmail,
      private_key: this.config.privateKey.replace(/\\n/g, '\n'),
    });

    await doc.loadInfo(); // loads document properties and worksheets
    return doc.sheetsByTitle["Sheet1"]; // you can change "Sheet1" if your sheet name is different
  }

  async appendFeedback(feedbackData: {
    timestamp: string;
    rating: number;
    type: string;
    comments: string;
    email?: string;
  }): Promise<{ success: boolean; message: string }> {
    try {
      const sheet = await this.getSheet();

      await sheet.addRow({
        Timestamp: feedbackData.timestamp,
        Rating: feedbackData.rating,
        Type: feedbackData.type,
        Comments: feedbackData.comments,
        Email: feedbackData.email || '',
      });

      return { success: true, message: "Feedback successfully appended." };
    } catch (error: any) {
      console.error("Google Sheets Error:", error);
      return { success: false, message: error.message };
    }
  }

  async getFeedback(): Promise<any[]> {
    try {
      const sheet = await this.getSheet();
      const rows = await sheet.getRows();

      return rows.map((row: any) => ({
        timestamp: row.Timestamp,
        rating: parseInt(row.Rating),
        type: row.Type,
        comments: row.Comments,
        email: row.Email,
      }));
    } catch (error) {
      console.error("Error fetching feedback:", error);
      return [];
    }
  }
}

// Environment configuration
export const googleSheetsConfig: GoogleSheetsConfig = {
  spreadsheetId: process.env.GOOGLE_SHEETS_SPREADSHEET_ID || 'mock_spreadsheet_id',
  range: process.env.GOOGLE_SHEETS_RANGE || 'Sheet1!A:E',
  serviceAccountEmail: process.env.GOOGLE_SERVICE_ACCOUNT_EMAIL || 'mock@example.com',
  privateKey: process.env.GOOGLE_PRIVATE_KEY || 'mock_private_key',
};

export const googleSheetsService = new GoogleSheetsService(googleSheetsConfig);