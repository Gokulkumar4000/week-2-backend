import { feedback, users, type Feedback, type InsertFeedback, type User, type InsertUser } from "../shared/schema";

export interface IStorage {
  // Feedback operations
  insertFeedback(feedback: InsertFeedback): Promise<Feedback>;
  getAllFeedback(): Promise<Feedback[]>;
  getFeedbackByType(type: string): Promise<Feedback[]>;
  getFeedbackByRating(rating: number): Promise<Feedback[]>;
  getFeedbackStats(): Promise<{
    total: number;
    avgRating: number;
    thisWeek: number;
    byType: Record<string, number>;
    byRating: Record<string, number>;
  }>;
  
  // User operations
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
}

export class MemStorage implements IStorage {
  private feedbackData: Map<number, Feedback>;
  private users: Map<number, User>;
  private currentFeedbackId: number;
  private currentUserId: number;

  constructor() {
    this.feedbackData = new Map();
    this.users = new Map();
    this.currentFeedbackId = 1;
    this.currentUserId = 1;

    // Create default admin user
    this.createUser({ username: "admin", password: "demo123" });
  }

  async insertFeedback(insertFeedback: InsertFeedback): Promise<Feedback> {
    const id = this.currentFeedbackId++;
    const feedbackItem: Feedback = {
      ...insertFeedback,
      id,
      timestamp: new Date(),
      email: insertFeedback.email || null,
    };
    this.feedbackData.set(id, feedbackItem);
    return feedbackItem;
  }

  async getAllFeedback(): Promise<Feedback[]> {
    return Array.from(this.feedbackData.values())
      .sort((a, b) => b.timestamp.getTime() - a.timestamp.getTime());
  }

  async getFeedbackByType(type: string): Promise<Feedback[]> {
    return Array.from(this.feedbackData.values())
      .filter(item => item.type === type)
      .sort((a, b) => b.timestamp.getTime() - a.timestamp.getTime());
  }

  async getFeedbackByRating(rating: number): Promise<Feedback[]> {
    return Array.from(this.feedbackData.values())
      .filter(item => item.rating === rating)
      .sort((a, b) => b.timestamp.getTime() - a.timestamp.getTime());
  }

  async getFeedbackStats() {
    const allFeedback = Array.from(this.feedbackData.values());
    const total = allFeedback.length;
    
    if (total === 0) {
      return {
        total: 0,
        avgRating: 0,
        thisWeek: 0,
        byType: {},
        byRating: {},
      };
    }

    const avgRating = allFeedback.reduce((sum, item) => sum + item.rating, 0) / total;
    
    const oneWeekAgo = new Date();
    oneWeekAgo.setDate(oneWeekAgo.getDate() - 7);
    const thisWeek = allFeedback.filter(item => item.timestamp >= oneWeekAgo).length;

    const byType: Record<string, number> = {};
    const byRating: Record<string, number> = {};

    allFeedback.forEach(item => {
      byType[item.type] = (byType[item.type] || 0) + 1;
      byRating[item.rating.toString()] = (byRating[item.rating.toString()] || 0) + 1;
    });

    return {
      total,
      avgRating: Math.round(avgRating * 10) / 10,
      thisWeek,
      byType,
      byRating,
    };
  }

  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.currentUserId++;
    const user: User = { ...insertUser, id };
    this.users.set(id, user);
    return user;
  }
}

export const storage = new MemStorage();
