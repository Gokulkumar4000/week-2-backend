import type { Express } from "express";
import { createServer, type Server } from "http";
import session from "express-session";
import { storage } from "./storage";
import { insertFeedbackSchema, loginSchema } from "../shared/schema";
import { googleSheetsService } from "./google-sheets";
import { z } from "zod";

declare module 'express-session' {
  interface SessionData {
    userId?: number;
    isAdmin?: boolean;
  }
}

export async function registerRoutes(app: Express): Promise<Server> {
  // Configure sessions
  app.use(session({
    secret: process.env.SESSION_SECRET || 'feedback-system-secret-key',
    resave: false,
    saveUninitialized: false,
    cookie: {
      secure: process.env.NODE_ENV === 'production',
      httpOnly: true,
      maxAge: 24 * 60 * 60 * 1000, // 24 hours
    },
  }));

  // Feedback submission endpoint
  app.post("/api/feedback", async (req, res) => {
    try {
      const validatedData = insertFeedbackSchema.parse(req.body);
      const feedback = await storage.insertFeedback(validatedData);
      
      // Save to Google Sheets
      try {
        await googleSheetsService.appendFeedback({
          timestamp: feedback.timestamp.toISOString(),
          rating: feedback.rating,
          type: feedback.type,
          comments: feedback.comments,
          email: feedback.email || undefined,
        });
        console.log('Feedback saved to Google Sheets successfully');
      } catch (error) {
        console.error('Failed to save to Google Sheets:', error);
        // Continue even if Google Sheets fails
      }
      
      res.json({ success: true, message: "Feedback submitted successfully", data: feedback });
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ 
          success: false, 
          message: "Validation error", 
          errors: error.errors 
        });
      }
      console.error('Error submitting feedback:', error);
      res.status(500).json({ success: false, message: "Internal server error" });
    }
  });

  // Admin login endpoint
  app.post("/api/auth/login", async (req, res) => {
    try {
      const { username, password } = loginSchema.parse(req.body);
      
      const user = await storage.getUserByUsername(username);
      if (!user || user.password !== password) {
        return res.status(401).json({ success: false, message: "Invalid credentials" });
      }

      req.session.userId = user.id;
      req.session.isAdmin = true;
      
      res.json({ success: true, message: "Login successful" });
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ 
          success: false, 
          message: "Validation error", 
          errors: error.errors 
        });
      }
      console.error('Login error:', error);
      res.status(500).json({ success: false, message: "Internal server error" });
    }
  });

  // Admin logout endpoint
  app.post("/api/auth/logout", (req, res) => {
    req.session.destroy((err) => {
      if (err) {
        console.error('Logout error:', err);
        return res.status(500).json({ success: false, message: "Logout failed" });
      }
      res.json({ success: true, message: "Logout successful" });
    });
  });

  // Check auth status
  app.get("/api/auth/status", (req, res) => {
    res.json({ 
      isAuthenticated: !!req.session.isAdmin,
      isAdmin: !!req.session.isAdmin 
    });
  });

  // Protected admin routes
  const requireAuth = (req: any, res: any, next: any) => {
    if (!req.session.isAdmin) {
      return res.status(401).json({ success: false, message: "Authentication required" });
    }
    next();
  };

  // Get all feedback (admin only)
  app.get("/api/admin/feedback", requireAuth, async (req, res) => {
    try {
      const { type, rating, page = 1, limit = 10 } = req.query;
      let feedback;

      if (type) {
        feedback = await storage.getFeedbackByType(type as string);
      } else if (rating) {
        feedback = await storage.getFeedbackByRating(parseInt(rating as string));
      } else {
        feedback = await storage.getAllFeedback();
      }

      // Pagination
      const startIndex = (parseInt(page as string) - 1) * parseInt(limit as string);
      const endIndex = startIndex + parseInt(limit as string);
      const paginatedFeedback = feedback.slice(startIndex, endIndex);

      res.json({
        success: true,
        data: paginatedFeedback,
        pagination: {
          total: feedback.length,
          page: parseInt(page as string),
          limit: parseInt(limit as string),
          totalPages: Math.ceil(feedback.length / parseInt(limit as string)),
        },
      });
    } catch (error) {
      console.error('Error fetching feedback:', error);
      res.status(500).json({ success: false, message: "Internal server error" });
    }
  });

  // Get feedback statistics (admin only)
  app.get("/api/admin/stats", requireAuth, async (req, res) => {
    try {
      const stats = await storage.getFeedbackStats();
      res.json({ success: true, data: stats });
    } catch (error) {
      console.error('Error fetching stats:', error);
      res.status(500).json({ success: false, message: "Internal server error" });
    }
  });

  // Export feedback as CSV (admin only)
  app.get("/api/admin/export", requireAuth, async (req, res) => {
    try {
      const feedback = await storage.getAllFeedback();
      
      const csvHeader = "ID,Timestamp,Rating,Type,Comments,Email\n";
      const csvData = feedback.map(item => 
        `${item.id},"${item.timestamp.toISOString()}",${item.rating},"${item.type}","${item.comments.replace(/"/g, '""')}","${item.email || ''}"`
      ).join('\n');
      
      const csv = csvHeader + csvData;
      
      res.setHeader('Content-Type', 'text/csv');
      res.setHeader('Content-Disposition', 'attachment; filename="feedback-export.csv"');
      res.send(csv);
    } catch (error) {
      console.error('Error exporting feedback:', error);
      res.status(500).json({ success: false, message: "Export failed" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
