import { z } from "zod";

// Shared types for frontend
export const insertFeedbackSchema = z.object({
  rating: z.number().min(1).max(5),
  type: z.enum(["Bug Report", "Suggestion", "Praise", "Question", "Complaint"]),
  comments: z.string().min(1).max(500),
  email: z.string().email().optional().or(z.literal("")),
});

export const loginSchema = z.object({
  username: z.string().min(1, "Username is required"),
  password: z.string().min(1, "Password is required"),
});

export type InsertFeedback = z.infer<typeof insertFeedbackSchema>;
export type LoginCredentials = z.infer<typeof loginSchema>;

export interface Feedback {
  id: number;
  rating: number;
  type: string;
  comments: string;
  email: string | null;
  timestamp: Date;
}

export interface User {
  id: number;
  username: string;
  password: string;
}