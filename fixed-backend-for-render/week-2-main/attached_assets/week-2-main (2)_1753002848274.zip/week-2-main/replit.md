# Customer Feedback System Application

## Overview

This is a comprehensive full-stack customer feedback system built with React (frontend), Chart.js (for data visualization), Express.js backend, and includes Google Sheets API integration setup. The system allows customers to submit feedback with star ratings, feedback types, and comments, while providing administrators with a powerful dashboard to analyze and manage all feedback data. The application features a modern, responsive UI built with shadcn/ui components and Tailwind CSS.

## User Preferences

Preferred communication style: Simple, everyday language.

## Recent Changes

### July 19, 2025 - Complete Customer Feedback System Implementation
- Built comprehensive customer feedback form with 1-5 star ratings
- Implemented feedback type selection (Bug Report, Suggestion, Praise, Question, Complaint)
- Added optional email collection for customer follow-up
- Created admin login system with demo credentials (admin/demo123)  
- Built admin dashboard with Chart.js visualizations (pie chart for feedback types, bar chart for ratings)
- Added feedback filtering by type and rating
- Implemented CSV export functionality for feedback data
- Set up Google Sheets integration framework with detailed setup instructions
- Fixed SelectItem React errors and authentication redirect issues
- Added responsive design with modern UI components
- Implemented session-based authentication with secure admin access

### July 19, 2025 - Project Restructure for Separate Deployment
- Separated frontend and backend into independent packages
- Created separate package.json files for frontend and backend
- Updated backend with CORS support for frontend-backend separation
- Modified API client to support external backend URL configuration
- Added comprehensive deployment guide with multiple hosting options
- Created environment variable examples for both frontend and backend
- Integrated Google Sheets service directly into backend API routes
- Added health check endpoint for backend monitoring
- Updated project structure for independent scaling and deployment

## System Architecture

### Frontend Architecture
- **Framework**: React 18 with TypeScript
- **Routing**: Wouter for client-side routing
- **State Management**: TanStack Query (React Query) for server state management
- **UI Framework**: shadcn/ui components built on Radix UI primitives
- **Styling**: Tailwind CSS with CSS variables for theming
- **Build Tool**: Vite with hot module replacement
- **Form Handling**: React Hook Form with Zod validation

### Backend Architecture
- **Framework**: Express.js with TypeScript
- **Database**: PostgreSQL with Drizzle ORM
- **Session Management**: Express sessions with connect-pg-simple for PostgreSQL storage
- **API Design**: RESTful API with JSON responses
- **Environment**: Node.js with ES modules

### Database Design
The application uses a PostgreSQL database with two main tables:
- **feedback**: Stores user feedback with ratings, types, comments, and timestamps
- **users**: Stores admin user credentials for dashboard access

## Key Components

### Frontend Components
1. **Feedback Form**: Main user interface for submitting feedback with star ratings
2. **Admin Dashboard**: Protected interface for viewing feedback analytics and data
3. **Admin Login**: Authentication form for admin access
4. **Navigation**: Context-aware navigation with authentication state
5. **Charts**: Data visualization components using Chart.js for feedback analytics

### Backend Components
1. **Routes**: RESTful API endpoints for feedback submission and admin operations
2. **Storage Layer**: Abstracted storage interface with in-memory implementation
3. **Session Management**: Secure session handling with PostgreSQL persistence
4. **Validation**: Zod schemas for request/response validation

### UI Components
The application uses a comprehensive set of shadcn/ui components including:
- Form controls (Input, Textarea, Select, Button)
- Data display (Cards, Tables, Badges)
- Navigation (Dialogs, Sheets, Tooltips)
- Feedback (Toasts, Progress indicators)

## Data Flow

1. **Feedback Submission**:
   - User fills out feedback form with rating, type, and comments
   - Form validation occurs client-side using Zod schemas
   - Data is submitted to `/api/feedback` endpoint
   - Backend validates and stores feedback in database
   - Success/error feedback provided to user via toast notifications

2. **Admin Authentication**:
   - Admin enters credentials on login page
   - Credentials validated against user database
   - Session created and stored in PostgreSQL
   - Admin redirected to dashboard with authenticated state

3. **Dashboard Analytics**:
   - Dashboard fetches aggregated statistics from `/api/admin/stats`
   - Feedback data retrieved with filtering and pagination
   - Charts rendered using Chart.js for visual analytics
   - Real-time updates through React Query's caching system

## External Dependencies

### Key Dependencies
- **@neondatabase/serverless**: PostgreSQL database driver optimized for serverless
- **drizzle-orm**: Type-safe SQL query builder and ORM
- **@tanstack/react-query**: Server state management and caching
- **@radix-ui/***: Accessible UI primitives for components
- **chart.js**: Data visualization library for analytics
- **react-hook-form**: Performance-focused form library
- **zod**: TypeScript-first schema declaration and validation
- **date-fns**: Date utility library for timestamp formatting

### Development Tools
- **Vite**: Fast build tool with HMR
- **TypeScript**: Static type checking
- **Tailwind CSS**: Utility-first CSS framework
- **ESLint/Prettier**: Code quality and formatting (configured via components.json)

## Deployment Strategy

### Build Process
- **Frontend**: Vite builds the React application to `dist/public`
- **Backend**: esbuild bundles the Express server to `dist/index.js`
- **Database**: Drizzle migrations handle schema changes

### Environment Configuration
- **Development**: Uses `tsx` for hot reloading of the backend
- **Production**: Compiled JavaScript served with `node dist/index.js`
- **Database**: Requires `DATABASE_URL` environment variable for PostgreSQL connection

### Key Scripts
- `npm run dev`: Development mode with hot reloading
- `npm run build`: Production build for both frontend and backend
- `npm run start`: Production server startup
- `npm run db:push`: Apply database schema changes

The application is designed to work seamlessly on Replit with automatic environment provisioning and includes Replit-specific plugins for enhanced development experience.