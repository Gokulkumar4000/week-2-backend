# 🚀 Deploy Your Frontend - Step by Step

Your backend is working at `https://gokulkumar-week-2.onrender.com`

## Option 1: Netlify (Recommended - Easiest)

### Quick Deploy (5 minutes):
1. **Build your frontend locally:**
   ```bash
   cd frontend
   npm install
   npm run build
   ```

2. **Go to [netlify.com](https://netlify.com)** and sign up

3. **Deploy manually:**
   - Click "Deploy manually" 
   - Drag and drop your `frontend/dist` folder
   - Your site will be live instantly!

4. **Set environment variable:**
   - Go to Site Settings → Environment Variables
   - Add: `VITE_BACKEND_URL` = `https://gokulkumar-week-2.onrender.com`
   - Redeploy the site

### Or Deploy from GitHub:
1. Push your project to GitHub
2. Connect GitHub repo to Netlify
3. Set build settings:
   - **Base directory**: `frontend`
   - **Build command**: `npm install && npm run build`
   - **Publish directory**: `dist`
4. Add environment variable: `VITE_BACKEND_URL=https://gokulkumar-week-2.onrender.com`

---

## Option 2: Render Static Site

1. **Go to [render.com](https://render.com)** dashboard
2. **Click "New" → "Static Site"**
3. **Connect your GitHub repo**
4. **Settings:**
   - **Name**: `feedback-frontend`
   - **Root Directory**: `frontend`
   - **Build Command**: `npm install && npm run build`
   - **Publish Directory**: `dist`
5. **Environment Variables:**
   - `VITE_BACKEND_URL=https://gokulkumar-week-2.onrender.com`
6. **Deploy**

---

## Option 3: Vercel

1. **Go to [vercel.com](https://vercel.com)**
2. **Import your GitHub repo**
3. **Configure:**
   - **Root Directory**: `frontend`
   - **Build Command**: `npm run build`
   - **Output Directory**: `dist`
4. **Environment Variables:**
   - `VITE_BACKEND_URL=https://gokulkumar-week-2.onrender.com`

---

## After Frontend Deployment

1. **Get your frontend URL** (e.g., `https://your-app.netlify.app`)

2. **Update backend CORS settings:**
   - Go to your Render backend dashboard
   - Add environment variable:
     - **Key**: `FRONTEND_URL`
     - **Value**: `https://your-frontend-url.netlify.app`

3. **Test your complete app:**
   - Visit your frontend URL
   - Submit feedback
   - Login to admin: `admin` / `demo123`
   - Check dashboard

---

## Need Database & Google Sheets?

### Add PostgreSQL Database:
1. In Render dashboard → "New" → "PostgreSQL"
2. Copy the Internal Database URL
3. Add to backend environment: `DATABASE_URL=...`

### Add Google Sheets:
Add these to your backend environment variables:
```
GOOGLE_SHEETS_SPREADSHEET_ID=your_id
GOOGLE_SERVICE_ACCOUNT_EMAIL=your_email
GOOGLE_PRIVATE_KEY=your_key
```

---

**Choose Option 1 (Netlify) for the fastest deployment!**