import { useState } from "react";
import { cn } from "@/lib/utils";

interface StarRatingProps {
  value: number;
  onChange: (rating: number) => void;
  className?: string;
  disabled?: boolean;
}

export default function StarRating({ value, onChange, className, disabled = false }: StarRatingProps) {
  const [hoverValue, setHoverValue] = useState(0);

  const handleClick = (rating: number) => {
    if (!disabled) {
      onChange(rating);
    }
  };

  const handleMouseEnter = (rating: number) => {
    if (!disabled) {
      setHoverValue(rating);
    }
  };

  const handleMouseLeave = () => {
    if (!disabled) {
      setHoverValue(0);
    }
  };

  const getRatingText = (rating: number) => {
    const ratingTexts = {
      1: "Poor - We're sorry to hear that",
      2: "Fair - We can do better", 
      3: "Good - Thanks for your feedback",
      4: "Very Good - We appreciate it",
      5: "Excellent - Thank you!"
    };
    return ratingTexts[rating as keyof typeof ratingTexts] || "Click to rate";
  };

  const displayRating = hoverValue || value;

  return (
    <div className={cn("flex flex-col items-center", className)}>
      <div
        className="star-rating"
        onMouseLeave={handleMouseLeave}
      >
        {[1, 2, 3, 4, 5].map((rating) => (
          <span
            key={rating}
            className={cn(
              "star",
              {
                "active": rating <= displayRating,
                "inactive": rating > displayRating,
                "cursor-not-allowed": disabled,
              }
            )}
            onClick={() => handleClick(rating)}
            onMouseEnter={() => handleMouseEnter(rating)}
          >
            ★
          </span>
        ))}
      </div>
      <p className="text-center text-sm text-gray-500 mt-2">
        {getRatingText(displayRating)}
      </p>
    </div>
  );
}
