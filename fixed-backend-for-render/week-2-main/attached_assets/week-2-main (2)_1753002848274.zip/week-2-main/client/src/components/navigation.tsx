import { Button } from "@/components/ui/button";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useLocation } from "wouter";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

export default function Navigation() {
  const [location, navigate] = useLocation();
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: authStatus } = useQuery({
    queryKey: ['/api/auth/status'],
  });

  const logoutMutation = useMutation({
    mutationFn: async () => {
      const response = await apiRequest('POST', '/api/auth/logout');
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/auth/status'] });
      navigate('/');
      toast({
        title: "Logged out successfully",
        description: "You have been logged out of the admin panel.",
      });
    },
    onError: () => {
      toast({
        title: "Logout failed",
        description: "There was an error logging out. Please try again.",
        variant: "destructive",
      });
    },
  });

  const handleAdminClick = () => {
    if (authStatus?.isAuthenticated) {
      navigate('/admin/dashboard');
    } else {
      navigate('/admin/login');
    }
  };

  const handleLogout = () => {
    logoutMutation.mutate();
  };

  return (
    <header className="bg-white shadow-sm border-b border-gray-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-16">
          <div className="flex items-center">
            <Button
              variant="ghost"
              onClick={() => navigate('/')}
              className="text-xl font-bold text-gray-900 hover:bg-transparent"
            >
              FeedbackHub
            </Button>
          </div>
          <div className="flex items-center space-x-4">
            <Button
              variant="ghost"
              onClick={handleAdminClick}
              className="text-gray-700 hover:text-primary transition-colors duration-200 font-medium"
            >
              {authStatus?.isAuthenticated ? "Dashboard" : "Admin Dashboard"}
            </Button>
            {authStatus?.isAuthenticated && (
              <Button
                onClick={handleLogout}
                disabled={logoutMutation.isPending}
                variant="destructive"
                size="sm"
              >
                {logoutMutation.isPending ? "Logging out..." : "Logout"}
              </Button>
            )}
          </div>
        </div>
      </div>
    </header>
  );
}
