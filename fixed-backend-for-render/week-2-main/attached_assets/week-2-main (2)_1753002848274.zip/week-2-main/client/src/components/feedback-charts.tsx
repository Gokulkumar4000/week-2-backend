import { useEffect, useRef } from "react";
import { Chart as ChartJS, CategoryScale, LinearScale, BarElement, Title, Tooltip, Legend, ArcElement } from 'chart.js';
import { Bar, Pie } from 'react-chartjs-2';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";

ChartJS.register(
  CategoryScale,
  LinearScale,
  BarElement,
  Title,
  Tooltip,
  Legend,
  ArcElement
);

interface FeedbackChartsProps {
  stats: {
    byType: Record<string, number>;
    byRating: Record<string, number>;
  };
}

export default function FeedbackCharts({ stats }: FeedbackChartsProps) {
  // Feedback Types Pie Chart
  const typeChartData = {
    labels: Object.keys(stats.byType),
    datasets: [
      {
        data: Object.values(stats.byType),
        backgroundColor: [
          'hsl(217, 91%, 60%)', // Blue
          'hsl(0, 84%, 60%)',   // Red
          'hsl(142, 76%, 36%)', // Green
          'hsl(271, 81%, 56%)', // Purple
          'hsl(38, 92%, 50%)',  // Amber
        ],
        borderWidth: 2,
        borderColor: '#FFFFFF',
      },
    ],
  };

  const typeChartOptions = {
    responsive: true,
    maintainAspectRatio: false,
    plugins: {
      legend: {
        position: 'bottom' as const,
        labels: {
          padding: 20,
          usePointStyle: true,
        },
      },
      tooltip: {
        callbacks: {
          label: (context: any) => {
            const total = context.dataset.data.reduce((a: number, b: number) => a + b, 0);
            const percentage = ((context.raw / total) * 100).toFixed(1);
            return `${context.label}: ${context.raw} (${percentage}%)`;
          },
        },
      },
    },
  };

  // Ratings Bar Chart
  const ratingsData = ['1', '2', '3', '4', '5'].map(rating => stats.byRating[rating] || 0);
  const ratingsChartData = {
    labels: ['1 Star', '2 Stars', '3 Stars', '4 Stars', '5 Stars'],
    datasets: [
      {
        label: 'Number of Ratings',
        data: ratingsData,
        backgroundColor: [
          'hsl(0, 84%, 60%)',   // Red
          'hsl(38, 92%, 50%)',  // Amber
          'hsl(210, 16%, 52%)', // Gray
          'hsl(217, 91%, 60%)', // Blue
          'hsl(142, 76%, 36%)', // Green
        ],
        borderWidth: 1,
        borderColor: 'hsl(210, 16%, 82%)',
      },
    ],
  };

  const ratingsChartOptions = {
    responsive: true,
    maintainAspectRatio: false,
    plugins: {
      legend: {
        display: false,
      },
      tooltip: {
        callbacks: {
          label: (context: any) => {
            return `${context.label}: ${context.raw} ratings`;
          },
        },
      },
    },
    scales: {
      y: {
        beginAtZero: true,
        ticks: {
          stepSize: 1,
        },
      },
    },
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
      {/* Feedback Types Chart */}
      <Card>
        <CardHeader>
          <CardTitle className="text-xl font-bold text-gray-900">
            Feedback Types Distribution
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="relative h-64">
            {Object.keys(stats.byType).length > 0 ? (
              <Pie data={typeChartData} options={typeChartOptions} />
            ) : (
              <div className="flex items-center justify-center h-full text-gray-500">
                No feedback data available
              </div>
            )}
          </div>
        </CardContent>
      </Card>

      {/* Ratings Chart */}
      <Card>
        <CardHeader>
          <CardTitle className="text-xl font-bold text-gray-900">
            Rating Distribution
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="relative h-64">
            {ratingsData.some(count => count > 0) ? (
              <Bar data={ratingsChartData} options={ratingsChartOptions} />
            ) : (
              <div className="flex items-center justify-center h-full text-gray-500">
                No rating data available
              </div>
            )}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
