import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { useMutation } from "@tanstack/react-query";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent } from "@/components/ui/dialog";
import StarRating from "@/components/ui/star-rating";
import { insertFeedbackSchema, type InsertFeedback } from "@shared/schema";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { CheckCircle, Loader2 } from "lucide-react";

export default function FeedbackForm() {
  const [rating, setRating] = useState(0);
  const [charCount, setCharCount] = useState(0);
  const [showThankYou, setShowThankYou] = useState(false);
  const { toast } = useToast();

  const form = useForm<InsertFeedback>({
    resolver: zodResolver(insertFeedbackSchema),
    defaultValues: {
      rating: 0,
      type: "",
      comments: "",
      email: "",
    },
  });

  const submitFeedback = useMutation({
    mutationFn: async (data: InsertFeedback) => {
      const response = await apiRequest('POST', '/api/feedback', data);
      return response.json();
    },
    onSuccess: () => {
      setShowThankYou(true);
      form.reset();
      setRating(0);
      setCharCount(0);
    },
    onError: (error: any) => {
      toast({
        title: "Submission failed",
        description: error.message || "There was an error submitting your feedback. Please try again.",
        variant: "destructive",
      });
    },
  });

  const onSubmit = (data: InsertFeedback) => {
    if (rating === 0) {
      toast({
        title: "Rating required",
        description: "Please select a rating before submitting.",
        variant: "destructive",
      });
      return;
    }

    const submitData = {
      ...data,
      rating,
      email: data.email || undefined,
    };

    submitFeedback.mutate(submitData);
  };

  const handleCommentsChange = (value: string) => {
    setCharCount(value.length);
    form.setValue('comments', value);
  };

  return (
    <>
      <Card className="max-w-2xl mx-auto shadow-lg">
        <CardContent className="pt-8 p-8">
          <div className="text-center mb-8">
            <h2 className="text-3xl font-bold text-gray-900 mb-2">We Value Your Feedback</h2>
            <p className="text-gray-600">Help us improve by sharing your experience</p>
          </div>

          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
            {/* Star Rating */}
            <div>
              <Label className="block text-sm font-semibold text-gray-700 mb-3">
                Overall Rating <span className="text-red-500">*</span>
              </Label>
              <StarRating
                value={rating}
                onChange={setRating}
                disabled={submitFeedback.isPending}
              />
            </div>

            {/* Feedback Type */}
            <div>
              <Label className="block text-sm font-semibold text-gray-700 mb-2">
                Feedback Type <span className="text-red-500">*</span>
              </Label>
              <Select
                value={form.watch('type')}
                onValueChange={(value) => form.setValue('type', value)}
                disabled={submitFeedback.isPending}
              >
                <SelectTrigger className="w-full">
                  <SelectValue placeholder="Select feedback type" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="Bug Report">🐛 Bug Report</SelectItem>
                  <SelectItem value="Suggestion">💡 Suggestion</SelectItem>
                  <SelectItem value="Praise">👏 Praise</SelectItem>
                  <SelectItem value="Question">❓ Question</SelectItem>
                  <SelectItem value="Complaint">😞 Complaint</SelectItem>
                </SelectContent>
              </Select>
              {form.formState.errors.type && (
                <p className="text-sm text-red-500 mt-1">{form.formState.errors.type.message}</p>
              )}
            </div>

            {/* Comments */}
            <div>
              <Label className="block text-sm font-semibold text-gray-700 mb-2">
                Comments <span className="text-red-500">*</span>
              </Label>
              <Textarea
                {...form.register('comments')}
                onChange={(e) => handleCommentsChange(e.target.value)}
                rows={4}
                className="resize-none"
                placeholder="Please share your detailed feedback..."
                maxLength={500}
                disabled={submitFeedback.isPending}
              />
              <div className="flex justify-between text-sm text-gray-500 mt-1">
                <span>Maximum 500 characters</span>
                <span className={charCount > 450 ? 'text-red-500' : charCount > 350 ? 'text-yellow-500' : ''}>
                  {charCount}/500
                </span>
              </div>
              {form.formState.errors.comments && (
                <p className="text-sm text-red-500 mt-1">{form.formState.errors.comments.message}</p>
              )}
            </div>

            {/* Optional Email */}
            <div>
              <Label className="block text-sm font-semibold text-gray-700 mb-2">
                Email (Optional)
              </Label>
              <Input
                {...form.register('email')}
                type="email"
                placeholder="your.email@example.com"
                disabled={submitFeedback.isPending}
              />
              <p className="text-sm text-gray-500 mt-1">We'll only contact you if you need a response</p>
              {form.formState.errors.email && (
                <p className="text-sm text-red-500 mt-1">{form.formState.errors.email.message}</p>
              )}
            </div>

            {/* Submit Button */}
            <Button
              type="submit"
              className="w-full py-3 font-semibold"
              disabled={submitFeedback.isPending}
            >
              {submitFeedback.isPending ? (
                <>
                  <Loader2 className="animate-spin -ml-1 mr-3 h-5 w-5" />
                  Submitting...
                </>
              ) : (
                "Submit Feedback"
              )}
            </Button>
          </form>
        </CardContent>
      </Card>

      {/* Thank You Modal */}
      <Dialog open={showThankYou} onOpenChange={setShowThankYou}>
        <DialogContent className="sm:max-w-md">
          <div className="text-center fade-in">
            <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
              <CheckCircle className="w-8 h-8 text-green-600" />
            </div>
            <h3 className="text-2xl font-bold text-gray-900 mb-2">Thank You!</h3>
            <p className="text-gray-600 mb-6">
              Your feedback has been successfully submitted. We appreciate you taking the time to help us improve.
            </p>
            <Button onClick={() => setShowThankYou(false)}>
              Close
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </>
  );
}
