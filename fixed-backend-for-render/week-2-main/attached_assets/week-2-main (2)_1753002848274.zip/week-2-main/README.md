# Customer Feedback System

A modern, full-stack customer feedback system with React frontend, Express.js backend, Chart.js visualizations, and Google Sheets integration.

## 🚀 Features

- **Customer Feedback Form**: 1-5 star ratings, feedback type selection, and comments
- **Admin Dashboard**: Real-time analytics with Chart.js visualizations
- **Google Sheets Integration**: Automatic syncing of feedback data
- **Responsive Design**: Modern UI with shadcn/ui components
- **Secure Authentication**: Session-based admin access
- **Data Export**: CSV export functionality
- **Filtering & Pagination**: Advanced feedback management

## 📁 Project Structure

```
├── frontend/           # React application
│   ├── src/
│   ├── package.json
│   └── vite.config.ts
├── backend/            # Express API server
│   ├── src/
│   ├── shared/
│   ├── package.json
│   └── tsconfig.json
├── DEPLOYMENT_GUIDE.md
├── GOOGLE_SHEETS_SETUP.md
└── README.md
```

## 🏃‍♂️ Quick Start

### Development Mode

1. **Backend Setup**:
```bash
cd backend
cp .env.example .env
# Edit .env with your configuration
npm install
npm run dev
```

2. **Frontend Setup**:
```bash
cd frontend
cp .env.example .env
# Edit .env with backend URL
npm install
npm run dev
```

3. **Access the Application**:
   - Frontend: http://localhost:3000
   - Backend API: http://localhost:5000
   - Admin Login: admin / demo123

### Production Deployment

See [DEPLOYMENT_GUIDE.md](DEPLOYMENT_GUIDE.md) for detailed deployment instructions.

## 🔧 Configuration

### Backend Environment Variables
```env
DATABASE_URL=postgresql://username:password@localhost:5432/feedback_db
SESSION_SECRET=your_session_secret
GOOGLE_SHEETS_SPREADSHEET_ID=your_spreadsheet_id
GOOGLE_SERVICE_ACCOUNT_EMAIL=your-service@project.iam.gserviceaccount.com
GOOGLE_PRIVATE_KEY="-----BEGIN PRIVATE KEY-----\n...\n-----END PRIVATE KEY-----"
FRONTEND_URL=http://localhost:3000
```

### Frontend Environment Variables
```env
VITE_BACKEND_URL=http://localhost:5000
```

## 📊 Google Sheets Integration

The system automatically saves feedback to Google Sheets. Follow the [GOOGLE_SHEETS_SETUP.md](GOOGLE_SHEETS_SETUP.md) guide to connect your own spreadsheet.

### Sheet Format
| Timestamp | Rating | Type | Comments | Email |
|-----------|--------|------|----------|-------|
| 2025-01-01T12:00:00Z | 5 | Praise | Great app! | user@example.com |

## 🎨 Tech Stack

### Frontend
- **React 18** with TypeScript
- **Vite** for development and building
- **TanStack Query** for state management
- **Wouter** for routing
- **shadcn/ui** + **Tailwind CSS** for styling
- **Chart.js** for data visualization
- **React Hook Form** + **Zod** for form handling

### Backend
- **Express.js** with TypeScript
- **PostgreSQL** with **Drizzle ORM**
- **Google Sheets API** integration
- **Express Sessions** for authentication
- **Zod** for validation

## 🔐 Admin Features

- **Secure Login**: Session-based authentication
- **Dashboard Analytics**: Visual charts and statistics
- **Feedback Management**: Filter, sort, and paginate feedback
- **Data Export**: Download feedback data as CSV
- **Real-time Updates**: Live data refresh

## 📱 Responsive Design

The application is fully responsive and works seamlessly on:
- Desktop computers
- Tablets
- Mobile devices

## 🛡️ Security Features

- **CORS Protection**: Configured for specific domains
- **Session Security**: Secure session management
- **Input Validation**: Comprehensive data validation
- **Environment Variables**: Secure configuration management

## 🔍 API Endpoints

### Public Endpoints
- `POST /api/feedback` - Submit feedback
- `GET /health` - Health check

### Admin Endpoints (Authentication Required)
- `POST /api/auth/login` - Admin login
- `POST /api/auth/logout` - Admin logout
- `GET /api/auth/status` - Check authentication
- `GET /api/admin/feedback` - Get feedback data
- `GET /api/admin/stats` - Get analytics
- `GET /api/admin/export` - Export CSV

## 🚀 Deployment Options

### Frontend
- **Static Hosting**: Netlify, Vercel, GitHub Pages
- **CDN**: Cloudflare, AWS CloudFront
- **Traditional Server**: nginx, Apache

### Backend
- **Platform as a Service**: Heroku, Railway, Render
- **Virtual Private Server**: DigitalOcean, Linode
- **Container Platforms**: Docker, Kubernetes

### Database
- **Managed PostgreSQL**: Neon, Supabase, AWS RDS
- **Self-hosted**: PostgreSQL on VPS

## 🤝 Contributing

1. Fork the repository
2. Create your feature branch
3. Commit your changes
4. Push to the branch
5. Create a Pull Request

## 📄 License

This project is licensed under the MIT License.

## 🆘 Support

- Check the [DEPLOYMENT_GUIDE.md](DEPLOYMENT_GUIDE.md) for deployment issues
- Review [GOOGLE_SHEETS_SETUP.md](GOOGLE_SHEETS_SETUP.md) for integration help
- Create an issue for bugs or feature requests

---

**Demo Credentials**: admin / demo123